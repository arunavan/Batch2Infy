package com.infy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
public class UserAuthentication {
	
	Log logger = LogFactory.getLog(UserAuthentication.class);
	
	public void loginUser(String username, String password) throws Exception{
		try {
			if(username.isBlank() || password.isBlank()) {
				throw new Exception("Invalid user");
			}
			logger.info(username+" logged in successfully");
			//System.out.println(username+"  success");
		} catch(Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
	}
}
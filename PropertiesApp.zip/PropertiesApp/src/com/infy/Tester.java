package com.infy;

public class Tester {
	public static void main(String[] args) {
		try {
			UserAuthentication authentication = new UserAuthentication();
			authentication.loginUser("asdfghjwerewrw", "");
		
		} catch(Exception exception) {
		
		}
	}
}
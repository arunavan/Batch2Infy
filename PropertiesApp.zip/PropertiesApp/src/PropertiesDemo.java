import java.util.Iterator;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;

public class PropertiesDemo {

	public static void main(String[] args) throws Exception{
		Configurations configurations = new Configurations();
		PropertiesConfiguration config = configurations.properties("infy.properties");
		
		System.out.println("Value for server.port=" + config.getProperty("server.port"));
		System.out.println("userid=" + config.getProperty("userid"));
		
		Iterator<String> keys = config.getKeys();
		
		while(keys.hasNext()) {
			String k=keys.next();
			System.out.println("Key : "+ k +" Value:  "+config.getProperty(k));
		}
		Integer value1 = Integer.parseInt((String) config.getProperty("value1"));
		Integer value2 = Integer.parseInt((String) config.getProperty("value2"));
		Integer sum = value1 + value2;
		System.out.println("Sum=" + sum);
	}

}
